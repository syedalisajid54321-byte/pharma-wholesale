// lib/screens/ledger_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/doctor.dart';
import '../models/transaction.dart';
import '../utils/app_theme.dart';
import '../utils/formatters.dart';

class LedgerScreen extends StatelessWidget {
  final Doctor doctor;
  const LedgerScreen({super.key, required this.doctor});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surface,
      appBar: AppBar(
        title: Text(doctor.name),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(70),
          child: Container(
            color: AppTheme.primary,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _chip('ټليفون', doctor.phone, Icons.phone, Colors.white70),
                _chip(
                  'پاتې قرض',
                  Fmt.money(doctor.balance),
                  Icons.account_balance_wallet,
                  doctor.balance > 0
                      ? Colors.redAccent.shade100
                      : Colors.greenAccent.shade100,
                ),
              ],
            ),
          ),
        ),
      ),
      body: _LedgerBody(doctor: doctor),
    );
  }

  Widget _chip(String label, String value, IconData icon, Color valueColor) {
    return Column(children: [
      Icon(icon, color: Colors.white70, size: 18),
      const SizedBox(height: 4),
      Text(value,
          style: GoogleFonts.cairo(
              color: valueColor, fontSize: 14, fontWeight: FontWeight.w700)),
      Text(label,
          style: GoogleFonts.cairo(color: Colors.white54, fontSize: 11)),
    ]);
  }
}

class _LedgerBody extends StatefulWidget {
  final Doctor doctor;
  const _LedgerBody({required this.doctor});

  @override
  State<_LedgerBody> createState() => _LedgerBodyState();
}

class _LedgerBodyState extends State<_LedgerBody> {
  final _db = FirebaseFirestore.instance;
  List<Transaction> _invoices = [];
  List<Transaction> _payments = [];
  bool _loading = true;
  final List<StreamSubscription> _subs = [];

  @override
  void initState() {
    super.initState();
    _subs.add(_db
        .collection('invoices')
        .where('doctorId', isEqualTo: widget.doctor.id)
        .snapshots()
        .listen((s) => setState(() {
              _invoices = s.docs
                  .map((d) => Transaction.fromMap(d.data(), d.id))
                  .toList();
              _loading = false;
            })));

    _subs.add(_db
        .collection('payments')
        .where('doctorId', isEqualTo: widget.doctor.id)
        .snapshots()
        .listen((s) => setState(() {
              _payments = s.docs
                  .map((d) => Transaction.fromMap(d.data(), d.id))
                  .toList();
              _loading = false;
            })));
  }

  @override
  void dispose() {
    for (final s in _subs) s.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    final all = [..._invoices, ..._payments]
      ..sort((a, b) => a.date.compareTo(b.date));

    if (all.isEmpty) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.receipt_outlined, size: 80, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text('هیڅ لیکدود نه دی',
              style: GoogleFonts.cairo(
                  color: AppTheme.textSecondary, fontSize: 18)),
        ]),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: all.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final txn = all[i];
        final isInvoice = txn.type == TransactionType.invoice;
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: isInvoice
                              ? AppTheme.warning.withOpacity(0.1)
                              : AppTheme.accent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(txn.reference,
                            style: GoogleFonts.cairo(
                              color: isInvoice
                                  ? AppTheme.warning
                                  : AppTheme.accent,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            )),
                      ),
                      const SizedBox(width: 8),
                      Icon(
                        isInvoice ? Icons.receipt_long : Icons.payments,
                        color:
                            isInvoice ? AppTheme.warning : AppTheme.accent,
                        size: 18,
                      ),
                    ]),
                    Text(isInvoice ? 'بیل' : 'ادایيګي',
                        style: GoogleFonts.cairo(
                            fontWeight: FontWeight.w700, fontSize: 14),
                        textDirection: TextDirection.rtl),
                  ],
                ),
                const SizedBox(height: 10),
                const Divider(height: 1),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(
                        isInvoice
                            ? '+ ${Fmt.money(txn.amount)}'
                            : '- ${Fmt.money(txn.amount)}',
                        style: GoogleFonts.cairo(
                          color: isInvoice ? AppTheme.danger : AppTheme.accent,
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text('پاتې: ${Fmt.money(txn.newBalance)}',
                          style: GoogleFonts.cairo(
                              color: AppTheme.primary,
                              fontSize: 12,
                              fontWeight: FontWeight.w600)),
                    ]),
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Text(Fmt.date(txn.date),
                          style: GoogleFonts.cairo(
                              color: AppTheme.textSecondary, fontSize: 12)),
                      if (txn.notes.isNotEmpty)
                        Text(txn.notes,
                            style: GoogleFonts.cairo(
                                color: AppTheme.textSecondary, fontSize: 11),
                            textDirection: TextDirection.rtl),
                    ]),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
